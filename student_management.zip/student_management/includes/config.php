<?php
// Define a constant BASE_PATH to store the absolute path of the parent directory
// __DIR__ returns the directory of the current script, and dirname() returns the parent directory of that path
define('BASE_PATH', dirname(__DIR__));
?>